# Hashapp Design

**Consumer-grade dark premium spending app for AI agents.**  
Demo-only frontend prototype. Centered on "Scout" (Research Agent). Inspired by Cash App — darker and more premium. Non-custodial model: funds live in the user's connected Base smart wallet with a scoped USDC allocation for Scout.

---

## Stack

- React 19 + Vite 7 + TypeScript
- Tailwind CSS v4 (`@tailwindcss/vite`)
- Framer Motion (animations)
- Wouter (client-side routing)
- wagmi v2 + viem (wallet connection — Base Sepolia)
- shadcn/ui components (Radix primitives)
- `@tanstack/react-query`

---

## Run

```bash
npm install   # or pnpm install / yarn install
npm run dev
```

App runs at `http://localhost:5173`

No environment variables required to run the demo frontend.

---

## Nav Structure

| Tab | Route | Purpose |
|-----|-------|---------|
| MONEY | `/money` | Wallet allocation, spend permissions, wallet connect |
| ACTIVITY | `/` | Live feed of Scout's transactions |
| SCOUT | `/agent` | Agent identity, operating state, constraints |
| RULES | `/rules` | Spending constraint toggles |
| — | `/receipt/:id` | Transaction receipt detail |

---

## Demo Flow (auto-runs on first load)

1. **Load** — Activity feed shows historical transactions (approved, auto-approved, blocked)
2. **+3s** — A DataStream Pro **spend permission request** slides into the feed (`$89/mo`)
3. **User taps "Grant Permission"** — entry becomes Approved
4. **User navigates to Rules → toggles off "Block spend permissions"**
5. **+2s** — A new DataStream Pro charge appears as **Blocked** (per-purchase cap rule)

Demo state (feed, rules, spend permissions, stage) persists in `localStorage` (`hashapp_demo_state`, version 2). Hard-refresh clears it, or clear `localStorage` manually to reset.

---

## What Is Real vs Still Simulated

### REAL
- **Wallet connection**: wagmi + viem connecting to Base Sepolia. Injected wallet (MetaMask, Coinbase Wallet browser extension) and Coinbase Wallet connector are active. When a wallet is connected, the real address is displayed on the Money and Scout pages. Disconnect is functional.
- **localStorage persistence**: All demo state persists across page refreshes.
- **Rule toggles**: State is reactive and persists. Toggling Rule 4 ("Block spend permissions") off triggers the blocked-entry flow.

### SIMULATED (demo only)
- **Transaction history**: Hardcoded feed items. No real on-chain transactions have occurred.
- **"Grant Permission" flow**: Approval is a state machine update in React. No contract call is made. The spend permission is not created on-chain.
- **USDC balance / allocation amounts**: Static values ($700 allocated, calculated from demo feed).
- **Trusted Destinations rail**: The shield badges are visual only — no on-chain verification.
- **Scout agent**: No real agent is running. All transaction descriptions are hardcoded intent strings.
- **spend permissions in Money/Scout**: Pulled from demo state, not from a real SpendPermissionManager contract.

### Ready for real integration
- `DemoContext.approvePending(id, realTxHash?)` accepts a real tx hash. When `isReal && txHash` are set on a `FeedItem`, the Receipt shows a live Basescan link.
- `wallet.ts` exposes the wagmi config. Adding a real SpendPermissionManager call to the "Grant Permission" button would complete the on-chain path.
- Agent page "Spending from" row is driven by `useAccount()` — connects to real wallet state automatically.

---

## Key Files

```
src/
├── App.tsx                    # WagmiProvider + QueryClient + DemoProvider + Router
├── config/wallet.ts           # wagmi config: Base Sepolia, injected + Coinbase Wallet
├── context/DemoContext.tsx    # All demo state, types, localStorage persistence
├── pages/
│   ├── Activity.tsx           # Feed, trusted destinations rail, pending approval card
│   ├── Money.tsx              # Allocation, spend permissions, wallet connect/disconnect
│   ├── Agent.tsx              # Scout identity, operating state, spend permissions
│   ├── Rules.tsx              # 5 rule toggles with toast feedback
│   └── Receipt.tsx            # Transaction detail, honest demo vs real proof labels
└── components/
    ├── layout/MobileLayout.tsx # Nav bar, mobile shell
    └── ui/AvatarIcon.tsx       # Shared avatar component
```

---

## Honesty Contract

This is the rule set applied in the current pass:

- No fake transaction hashes in the feed
- Receipt shows **"Demo transaction · no onchain proof"** for simulated items
- Basescan links only appear when `isReal && txHash` are set
- Rules footer: **"Rules managed by Hashapp"** (not "enforced onchain")
- Agent footer: **"ERC-8004 · Base Sepolia"** (no fake token ID)
- No dead CTAs: removed "Increase Scout's limit", "Adjust Scout's budget", "Pause Scout"
- "Protected by N rules" and "Active Constraints" navigate to real Rules page

---

## Spend Permission Integration Point

The SpendPermissionManager contract lives on Base Sepolia. When ready to connect the real "Grant Permission" flow:

1. Add the contract address and ABI to `src/config/spendPermission.ts`
2. Use `useWriteContract` from wagmi to call `approve()`
3. Pass the returned tx hash to `approvePending(id, txHash)` in DemoContext
4. The Receipt will automatically show the Basescan link

---

*Last updated: March 15, 2026 — Minimum truth pass complete.*
